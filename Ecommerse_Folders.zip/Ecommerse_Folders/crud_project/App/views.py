from rest_framework.views import APIView
# from django.shortcuts import render
from rest_framework.response import Response
from rest_framework import status
from .models import Product
from .serializers import ProductSerializer

class ProductList(APIView):
    def get(self, request,pk=None,format=None):
        id=pk
        if id is not None:
            prod=Product.objects.get(id=id)
            serializer = ProductSerializer(prod)
            return Response(serializer.data)
        prod=Product.objects.all()
        serializer = ProductSerializer(prod, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = ProductSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg':'Data Created sucessfull'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def put(self, request, pk):
        id=pk
        prod=Product.objects.get(pk=id)
        serializer = ProductSerializer(prod, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg':'Data Updated sucessfull'})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, pk):
            id=pk
            prod=Product.objects.get(pk=id)
            serializer = ProductSerializer(prod, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response({'msg':'partial Data Updated sucessfull'})
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        id=pk
        prod=Product.objects.get(pk=id)
        prod.delete()
        return Response({'msg':'Data Deleted sucessfull'},status=status.HTTP_204_NO_CONTENT)
   
